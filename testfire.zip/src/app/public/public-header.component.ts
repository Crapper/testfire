import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-public-header',
  templateUrl: './public-header.component.html'
})
export class PublicHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
